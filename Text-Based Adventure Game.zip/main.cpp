#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <chrono>
#include <thread>
using namespace std;
int main() {

	char test[] = "You are a young man with dreams od adventures\n "
	"You go on a expedition to the ancient pyramids with a team of well renowned archeologist\n"
	"While exploring the ancient ruins of the pyramids you find yourself lost from the rest of the group\n"
	"\n" ;
	
		cout << "You come across two paths in the sand" << endl;
		cout << "On the left you see a path with foot prints" << endl;
		cout << "On the right you see a path with tire marks" << endl;
		cout << "Left or Right?" << endl;
		string path; 
		cin >> path;
		if (path == "left") {
		
			cout << "You follow the path to find a local tribe ahead" << endl;
			cout << "You can ask them for help or continue down the path" << endl;
			cout << "Help or Continue?" << endl;
			string path7;
			cin >> path7;			
			if (path7 == "continue") {
				cout << "You continue untill you see a ggroup of people ahead" << endl;
				cout << "You confront them but quickly real;ize that they are hostile natives" << endl;
				cout << "Fight or run?" << endl;
				string path8;
				cin >> path8;
				if (path8 == "fight")
				cout << "You prepare to face a massive battle until one of the natuves men approaches you" << endl;
				cout << "Luckily they believe in a fair fight and give you a sword" << endl;
				cout << "You are challenged to fight the besst man from thier tribe" << endl;
				cout << "In panic you pick up a rock and chuck it at your oppent" << endl;
				cout << "he falls and you flee for the jungle" << endl;
				cout << "You run as fast as you can until you see a woden cabin in the woods" << endl;
				cout << "Enter or continue?" << endl;
				string path9;
				cin >> path9;
				if (path9 == "enter"){
					cout << "You find your friends inside the wooden of the cabin" << endl;
					cout << "They tell you it was just a prank >:(" << endl;
				}
				if (path9 == "continue") {
					cout << "You through the jungle but without any protection you find yourself staking out in a cave waiting for help" << endl;
					cout << "With no food or water you die in days :(" << endl;
				}
			}
			if (path7 == "help") {
				cout << "The you straight ahead in the wilderness telling you they saw some strangers walking towards that way" << endl;
				cout << "They tell you to follow the sun through the forest" << endl;
				cout << "Halfway through the clouds block the sun and you are faced with a tough decision" << endl;
				cout << "Left or Right?" << endl;
				string path11;
				cin >> path11;
				//error here
				if (path11 == "left"){
					cout << "On the left you find a broken road with a gypsy waiting on its side" << endl;
					cout << "She instructs you to follow the path to find your friends" << endl;
					cout << "follow or turn back" << endl;
					string path10;
					cin >> path10;
					
					if (path10 == "turn back") {
						cout << "You turn back but are lost as to where to go " << endl;
						cout << "You lose interest in finding your friends and call a uber back home" << endl;
						cout << "Congrats, i think?" << endl;
						
						if (path10 == "follow"){
							cout << "The gypsy didnt lie to you" << endl;
							cout << "You find your friends" << endl;
							cout << "They tell you that they were playing hide and seek >:(" << endl;
						}
					}
				}
				if (path11 == "right") {
					cout << "You find literally nothing on this path" << endl;
					cout << "But you find a area tp settle down near a river and become just like tarzan" << endl;
					cout << "congratulations :)" << endl;
				}
			}
			if (path == "right") {
			cout << "You follow the path untill you come across a cart parked in the sand" << endl;
			cout << "You can either explore the cart or continue on into the wilderness" << endl;
			cout << "search or continue?" << endl;
		   
			string path2;
			cin >> path2;
			if (path2 == "search") {
				cout << "You find that the car still has some gas in it" << endl;
				cout << "You can either drive through the mud or go through the shallow waters" << endl;
				cout << "mud or water?" << endl;
				
				string path3;
				cin >> path3;
				if (path3 == "mud"){
					cout << "You cross the mud successfully and find a strange cabin" << endl;
					cout << "Do you enter or continue?" << endl;
					cout << "enter or continue?" << endl;
					string path6;
					cin >> path6;
					if (path6 == "enter") {
						cout << "Inside you find your friends lounging arond a warm fire " << endl;
						cout << "It was all a big prank :)" << endl;
						if (path6 == "continue") {
							cout << "You continue through the desert and find no sign of any clues to your friends whereabouts" << endl;
							cout << "While wandering through the desert you are bite by a rattlesnake" << endl;
							cout << "You die the next day" << endl;
							cout << "Try again :(" << endl;
						}
					}
				}
				if (path3 == "water") {
					cout << "You attempt tp croos the shallow water but hit a rack halfway through" << endl;
					cout << "You fall in the water and you are eaten alive by alligators" << endl;
					cout << "Try again :(" << endl;
				}
			}
			if (path2 == "continue") {
				cout << "You see some mud and shallow water ahead" << endl;
				cout << "You must choose which way to move forward" << endl;
				cout << "mud or water?" << endl;
				string path4;
				cin >> path4;
				
				if (path4 == "mud"){
					cout << "You quickly realize that mud is quicksand and meet your demise" << endl;
					cout << "Try again :(" << endl;
				}
				if (path4 == "water") {
					cout << "You sprint through the water" << endl;
					cout << "dodging all the nasty beats that may lurk within it" << endl;
					cout << "You continue until you see a path straight ahead and a path to your right" << endl;
					cout << "straight or right" << endl;
					
					string path5;
					cin >> path5;
					if (path5 == "Straight") {
						cout << "You go forward and follow the path until day break" << endl;
						cout << "As you are walking in the darkness you suddenly feel a sharp pain in your leg" << endl;
						cout << "You have fallen into a natives animal trap left to die" << endl;
						cout << "Try again :(" << endl;
					}
					if (path5 == "right") {
						cout << "You find a cabin in the woods" << endl;
						cout << "You enter it looking for shelter for the night" << endl;
			            cout << "Inside you find your friends" << endl;
						cout << "It was all a big prank :)" << endl; 
					}
				}
			}
		}
	}
	else{
	
		cout << "Invalid input" << endl;
		cin >> path;
   }
	
}
  
	


